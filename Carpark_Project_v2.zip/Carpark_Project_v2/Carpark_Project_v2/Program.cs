﻿using System;

namespace Carpark_Project_v2
{

/*
 by oguztheaxl
github.com/oguztheaxl
 */

    class Program
    {
        static void Main(string[] args)
        {
            carpark_Projectv1();
        }
        static void carpark_Projectv1()
        {
            Console.WriteLine("Welcome to Carpark Fee Calculater");

            Vehicle_type bus = new Vehicle_type(VEHICLE.BUS, 6, 21.5F);
            Vehicle_type taxi = new Vehicle_type(VEHICLE.TAXI, 5, 20);
            Vehicle_type cvehicle = new Vehicle_type(VEHICLE.COMMERCIAL_VEHICLE, 6.5F, 25);

            do
            {
                Console.WriteLine();
                Console.WriteLine(" for Bus (b)");
                Console.WriteLine(" for Taxi (t)");
                Console.WriteLine(" for Commertial vehicle (v)");
                Console.WriteLine(" to Clear the console (c)");
                Console.WriteLine(" to Exit (x)");
                Console.WriteLine();
                Console.Write("what is your choice ?: ");


                string v_input = Console.ReadLine().ToUpper();

                switch (v_input)
                {

                    case "B":
                        calculateFee(bus);
                        continue;
                    case "T":
                        calculateFee(taxi);
                        continue;
                    case "V":
                        calculateFee(cvehicle);
                        continue;
                    case "C":
                        Console.Clear();
                        break;
                    case "X":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid input, please try again.");
                        continue;
                }


            } while (true);




        }



        static void calculateFee(Vehicle_type vehicle)
        {
            int hour;
            do
            {
                Console.Write("please enter time: ");
                if (!int.TryParse(Console.ReadLine(), out hour))
                {
                    Console.WriteLine("please enter in natural number format, try again");
                    continue;
                }
                break;
            } while(true);

            float topfee = vehicle.Hourlyfee + ((((vehicle.Extrahouryfee + 100) / 100) * vehicle.Hourlyfee) * (hour - 1 ));
            Console.WriteLine("Total fee you have to pay: " + topfee);
            

        }
    }

    public enum VEHICLE
    {
        BUS,
        COMMERCIAL_VEHICLE,
        TAXI
    }

}
