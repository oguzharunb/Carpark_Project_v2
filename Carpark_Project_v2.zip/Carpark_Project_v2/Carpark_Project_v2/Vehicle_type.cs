﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Carpark_Project_v2
{
    class Vehicle_type
    {
        public VEHICLE Vehicle { get; }
        public float Hourlyfee { get; }
        public float Extrahouryfee { get; }

        public Vehicle_type(VEHICLE vehicle, float hourlyfee, float extrahf)
        {
            this.Vehicle = vehicle;
            this.Hourlyfee = hourlyfee;
            this.Extrahouryfee = extrahf;
        }


    }
}
